(function ($) {
    'use strict';
    $(document).ready(function () {

        // Add + and - buttons
        var quantityField = $('.quantity input[type=number]');
        quantityField.before('<button type="button" class="qty-btn qty-minus">-</button>');
        quantityField.after('<button type="button" class="qty-btn qty-plus">+</button>');

        // Increase quantity
        $('.qty-plus').on('click', function () {
            var currentVal = parseInt(quantityField.val());
            if (!isNaN(currentVal)) {
                quantityField.val(currentVal + 1);
            }
        });

        // Decrease quantity
        $('.qty-minus').on('click', function () {
            var currentVal = parseInt(quantityField.val());
            if (!isNaN(currentVal) && currentVal > 1) {
                quantityField.val(currentVal - 1);
            }
        });

        // Select options to look like buttons instead of a dropdown.
        $('.option-button').on('click', function() {
            var $button = $(this);
            var value = $button.data('value');
            var $select = $button.closest('tr').find('.hidden-select');
    
            // Deselect all buttons and select the clicked one
            $button.closest('.button-options').find('.option-button').removeClass('selected');
            $button.addClass('selected');
    
            // Update the hidden select box and trigger change
            $select.val(value).trigger('change');
        });

        // Tabs Scroll Area
        $('.gpsc-scroll .gpsc-tab-btns button').on('click', function () {
            const target = '#' + $(this).data('target');
            $('html, body').animate({
                scrollTop: $(target).offset().top - 100
            }, 800);
        });

        // Tab Filtering Area
        const buttons = $('.gpsc-tab .gpsc-tab-btns button');
        const contents = $('.gpsc-tab .gpsc-tab-contents');
        buttons.on('click', function () {
            const target = $(this).data('target');
            contents.each(function () {
                if ($(this).attr('id') === target) {
                    $(this).fadeIn();
                } else {
                    $(this).removeClass('show').fadeOut();
                }
            });

            // Remove active class from all buttons
            buttons.removeClass('active');
            // Add active class to the clicked button
            $(this).addClass('active');
        });

        /**
         * Reply Button.
        */
        var baseUrl = window.location.href.split('?')[0].split('#')[0];

        $('li.review').each(function () {
            // Get the comment ID from the element's ID attribute
            var commentId = $(this).attr('id').split('-').pop();

            // Create the reply link
            var replyLink = $('<a>', {
                text: 'Reply',
                href: baseUrl + '?replytocom=' + commentId + '#respond',
                class: 'reply-link'
            });

            // Append the reply link after the comment content
            $(this).children('.comment_container').append(replyLink);
        });
        // Replace the text "Cancel reply" with "Cancel"
        $('a#cancel-comment-reply-link').each(function() {
            if ($(this).text().trim() === 'Cancel reply') {
                $(this).text('Cancle');
            }
        });

        /**
          *  Toggle Button Area
        */

            // Create a wrapper div for the switch
    var $elementWrapper = $('<div class="gpsc-toggle-button-wrapper"></div>');

    // Create the toggle switch
    var $toggleSwitch = $(
        '<span class="gpsc-toggle-text">Reply with Rating</span><label class="gpsc-switch">' +
            '<input type="checkbox">' +
            '<span class="gpsc-slider round"></span>' +
        '</label><span class="gpsc-toggle-text">Reply without Rating</span>'
    );
    
    // Append the switch to the wrapper
    $elementWrapper.append($toggleSwitch);

    // Insert the wrapper before the review_form_wrapper
    $('#review_form_wrapper').before($elementWrapper);

    // Initialize by showing the review_form_wrapper and hiding the respond section
    $('#review_form_wrapper').show();
    $('.reply-box').hide();

    // Add change event listener to the switch
    $toggleSwitch.find('input').on('change', function() {
        if ($(this).is(':checked')) {
            $('#review_form_wrapper').hide();
            $('.reply-box').show();
            
        } else {
            $('#review_form_wrapper').show();
            $('.reply-box').hide();
        }
    });





    });
})(jQuery);


// For gallery Lightbox
document.addEventListener('DOMContentLoaded', function () {
    var initPhotoSwipeFromDOM = function (gallerySelector) {
        var parseThumbnailElements = function (el) {
            var thumbElements = el.querySelectorAll('figure'),
                numNodes = thumbElements.length,
                items = [],
                figureEl,
                linkEl,
                size,
                item;

            for (var i = 0; i < numNodes; i++) {
                figureEl = thumbElements[i];
                linkEl = figureEl.querySelector('a');
                size = linkEl.getAttribute('data-size').split('x');

                item = {
                    src: linkEl.getAttribute('href'),
                    w: parseInt(size[0], 10),
                    h: parseInt(size[1], 10)
                };

                if (figureEl.children.length > 1) {
                    item.title = figureEl.querySelector('figcaption').innerHTML;
                }

                if (linkEl.children.length > 0) {
                    item.msrc = linkEl.children[0].getAttribute('src');
                }

                item.el = figureEl;
                items.push(item);
            }

            return items;
        };

        var closest = function closest(el, fn) {
            return el && (fn(el) ? el : closest(el.parentNode, fn));
        };

        var onThumbnailsClick = function (e) {
            e = e || window.event;
            e.preventDefault ? e.preventDefault() : e.returnValue = false;

            var eTarget = e.target || e.srcElement;

            var clickedListItem = closest(eTarget, function (el) {
                return el.tagName && el.tagName.toUpperCase() === 'FIGURE';
            });

            if (!clickedListItem) {
                return;
            }

            var clickedGallery = clickedListItem.parentNode,
                childNodes = clickedListItem.parentNode.querySelectorAll('figure'),
                numChildNodes = childNodes.length,
                nodeIndex = 0,
                index;

            for (var i = 0; i < numChildNodes; i++) {
                if (childNodes[i] === clickedListItem) {
                    index = i;
                    break;
                }
            }

            if (index >= 0) {
                openPhotoSwipe(index, clickedGallery);
            }
            return false;
        };

        var openPhotoSwipe = function (index, galleryElement, disableAnimation, fromURL) {
            var pswpElement = document.querySelectorAll('.pswp')[0],
                gallery,
                options,
                items;

            items = parseThumbnailElements(galleryElement);

            options = {
                galleryUID: galleryElement.getAttribute('data-pswp-uid'),
                getThumbBoundsFn: function (index) {
                    var thumbnail = items[index].el.getElementsByTagName('img')[0],
                        pageYScroll = window.pageYOffset || document.documentElement.scrollTop,
                        rect = thumbnail.getBoundingClientRect();

                    return { x: rect.left, y: rect.top + pageYScroll, w: rect.width };
                }
            };

            if (fromURL) {
                if (options.galleryPIDs) {
                    for (var j = 0; j < items.length; j++) {
                        if (items[j].pid == index) {
                            options.index = j;
                            break;
                        }
                    }
                } else {
                    options.index = parseInt(index, 10) - 1;
                }
            } else {
                options.index = parseInt(index, 10);
            }

            if (isNaN(options.index)) {
                return;
            }

            if (disableAnimation) {
                options.showAnimationDuration = 0;
            }

            gallery = new PhotoSwipe(pswpElement, PhotoSwipeUI_Default, items, options);
            gallery.init();
        };

        var galleryElements = document.querySelectorAll(gallerySelector);

        for (var i = 0, l = galleryElements.length; i < l; i++) {
            galleryElements[i].setAttribute('data-pswp-uid', i + 1);
            galleryElements[i].onclick = onThumbnailsClick;
        }
    };
    initPhotoSwipeFromDOM('.gpsc-product-gallery');
});