(function( $ ) {
	'use strict';
    $(document).ready(function () {

        $('.gpsc-group-tabs').each(function() {
            $(this).tabs();

        });
    });

})( jQuery );