<?php if ( ! defined( 'ABSPATH' ) ) {
	die; } // Cannot access directly.

//
// Create a section.
WPGPSC::createSection(
	$prefix,
	array(
		'title'  => __( 'Single Product Page', 'gpsc-product-slider-carousel' ),
		'icon'   => 'fas fa-tshirt',
		'fields' => array(

			array(
				'id'         => 'gpsc_woo_templ_activated',
				'type'       => 'switcher',
				'title'      => 'Single Product Page Template',
				'subtitle'   => 'Want to execute single product page template or not?',
				'text_on'    => 'Activate',
				'text_off'   => 'Deactivate',
				'text_width' => 100,
				'default'    => false,
			),
			array(
				'id'             => 'wpgpsc_prod_banner',
				'type'           => 'media',
				'title'          => __( 'Banner Image', 'wpas_editorial_rating' ),
				'subtitle'       => __( 'Set a banner image form the media.<br>Default Width: 500x100(px)', 'wpas_editorial_rating' ),
				'library'        => 'image',
				'url'            => false,
				'preview_size'   => 'full',
				'preview_width'  => '500',
				'preview_height' => '100',
				'default'        => array(
					'url'       => GPSC_PLUG_DIR_URL_FILE . 'public/img/single-page-banner.jpg',
					'thumbnail' => GPSC_PLUG_DIR_URL_FILE . 'public/img/single-page-banner.jpg',
				),
				'dependency'     => array( 'gpsc_woo_templ_activated', '==', 'true' ),
			),
			array(
				'id'         => 'gpsc_tabbed_content',
				'type'       => 'switcher',
				'title'      => 'Show Content as Tabbed',
				'subtitle'   => 'Show product content as tabbed or not?',
				'default'    => false,
				'dependency' => array( 'gpsc_woo_templ_activated', '==', 'true' ),
			),
		),
	)
);
