<?php if ( ! defined( 'ABSPATH' )  ) { die; } // Cannot access directly.

//
// Metabox of the PAGE
// Set a unique slug-like ID
//
$wpgpsc_prod_page_opts = '_prefix_prod_page_opt';

//
// Create a metabox
//
WPGPSC::createMetabox( $wpgpsc_prod_page_opts, array(
  'title'        => 'Single Page Custom Options',
  'post_type'    => 'product',
  'show_restore' => true,
) );

//
// Create a section
//
WPGPSC::createSection( $wpgpsc_prod_page_opts, array(
  'fields' => array(
	array(
		'type'    => 'content',
		'content' => '<style>.wpgpsc-styles-in-content {
			display: none;
		}
		h4.wpgpsc-cloneable-title .ui-icon {
			background: none !important;
		}
		.wpgpsc-field-group .wpgpsc-cloneable-helper {
			top: 50%;
			transform: translateY(-50%);
		}</style>',
		'class'   => 'wpgpsc-styles-in-content',
	),
	array(
		'id'         => 'wpgpsc_prod_spec_type',
		'type'       => 'button_set',
		'title'      => 'Product Specification Type',
		'options'    => array(
		  'dia' => 'DIY',
		  'raw' => 'Raw',
		),
		'default'    => 'raw',
	),
	array(
		'id'           => 'wpgpsc_prod_spec_table',
		'type'         => 'group',
		'button_title' => 'Add New Group',
		'fields'       => array(
		  array(
			'id'    => 'wpgpsc_prod_spec_group_name',
			'type'  => 'text',
			'title' => 'Group Name',
		  ),
		  array(
			'id'           => 'wpgpsc_prod_spec_list',
			'type'         => 'repeater',
			'button_title' => '<i class="fas fa-plus-circle"></i> Add New Row',
			'title'        => 'Specification List',
			'fields'       => array(
		  
			  array(
				'id'    => 'wpgpsc_prod_spec_list_item',
				'type'  => 'text',
				'title' => 'Item Name'
			  ),
			  array(
				'id'    => 'wpgpsc_prod_spec_item_value',
				'type'  => 'text',
				'title' => 'Item Value'
			  ),
			),
		  ),		  
		),
		'default'   => array(
		  array(
			'wpgpsc_prod_spec_group_name'     => 'General Information',
			'wpgpsc_prod_spec_list' => array(
			  array(
				'wpgpsc_prod_spec_list_item'  => 'Model',
				'wpgpsc_prod_spec_item_value' => 'EX1234',
			  ),
			  array(
				'wpgpsc_prod_spec_list_item'  => 'Market',
				'wpgpsc_prod_spec_item_value' => 'Global / Regional / etc.',
			  ),
			  array(
				'wpgpsc_prod_spec_list_item'  => 'Packaging',
				'wpgpsc_prod_spec_item_value' => 'Retail Box / Bulk / etc.',
			  ),
			  array(
				'wpgpsc_prod_spec_list_item'  => 'Retail Partners',
				'wpgpsc_prod_spec_item_value' => 'Example Store, Example Online',
			  ),
			),
		  ),
		  array(
			'wpgpsc_prod_spec_group_name'     => 'Features and Accessories',
			'wpgpsc_prod_spec_list' => array(
			  array(
				'wpgpsc_prod_spec_list_item'  => 'Special Features',
				'wpgpsc_prod_spec_item_value' => 'Water-resistant, Touchscreen',
			  ),
			  array(
				'wpgpsc_prod_spec_list_item'  => 'Included Accessories',
				'wpgpsc_prod_spec_item_value' => 'Charger, User Manual',
			  ),
			),
		  ),
		  array(
			'wpgpsc_prod_spec_group_name'     => 'Warranty and Certification',
			'wpgpsc_prod_spec_list' => array(
			  array(
				'wpgpsc_prod_spec_list_item'  => 'Warranty',
				'wpgpsc_prod_spec_item_value' => '1 year limited warranty',
			  ),
			  array(
				'wpgpsc_prod_spec_list_item'  => 'Certification',
				'wpgpsc_prod_spec_item_value' => 'CE / FCC / RoHS / etc.',
			  ),
			),
		  ),
		),
		'dependency' => array( 'wpgpsc_prod_spec_type', '==', 'dia' ),
	),
	array(
		'id'      => 'wpgpsc_prod_spec_table_raw',
		'type'    => 'wp_editor',
		'height'  => '300px',
		'default' => '<table cellspacing="0" cellpadding="0">
<thead>
<tr>
<td class="heading-row" colspan="3">General Information</td>
</tr>
</thead>
<tbody>
<tr>
<td class="name">Model</td>
<td class="value">EX1234</td>
</tr>
<tr>
<td class="name">Market</td>
<td class="value">Global / Regional / etc.</td>
</tr>
<tr>
<td class="name">Packaging</td>
<td class="value">Retail Box / Bulk / etc.</td>
</tr>
<tr>
<td class="name">Retail Partners</td>
<td class="value">Example Store, Example Online</td>
</tr>
</tbody>
<thead>
<tr>
<td class="heading-row" colspan="3">Features and Accessories</td>
</tr>
</thead>
<tbody>
<tr>
<td class="name">Special Features</td>
<td class="value">Water-resistant, Touchscreen</td>
</tr>
<tr>
<td class="name">Included Accessories</td>
<td class="value">Charger, User Manual</td>
</tr>
</tbody>
<thead>
<tr>
<td class="heading-row" colspan="3">Warranty and Certification</td>
</tr>
</thead>
<tbody>
<tr>
<td class="name">Warranty</td>
<td class="value">1 year limited warranty</td>
</tr>
<tr>
<td class="name">Certification</td>
<td class="value">CE / FCC / RoHS / etc.</td>
</tr>
</tbody>
</table>',
	'dependency' => array( 'wpgpsc_prod_spec_type', '==', 'raw' ),
	),
  )
) );
