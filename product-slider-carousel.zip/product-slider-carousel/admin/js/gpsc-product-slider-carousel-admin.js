(function( $ ) {
	'use strict';

	jQuery(document).ready(function ($) {

		// Admin menu preloader.
		$('#_wpgpsc_page_options').addClass('wpgpsc--after-none');
	});

})( jQuery );
